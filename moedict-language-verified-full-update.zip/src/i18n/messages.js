// messages.js (原始架構基礎上修改)
export default {
  zh: "華語辭典",
  nan: "臺灣台語",
  hak: "臺灣客語"
};