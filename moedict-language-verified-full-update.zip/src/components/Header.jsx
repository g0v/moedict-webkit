// Header.jsx (原始架構基礎上修改)
export const languageOptions = [
  { code: 'zh', name: '華語辭典' },
  { code: 'nan', name: '臺灣台語' },
  { code: 'hak', name: '臺灣客語' }
];