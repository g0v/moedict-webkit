// Nav.jsx (原始架構基礎上修改)
const navItems = [
  { code: 'zh', label: '華語辭典' },
  { code: 'nan', label: '臺灣台語' },
  { code: 'hak', label: '臺灣客語' }
];
export default navItems;
